package fantasy.editor;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class FullscreenActivity extends AppCompatActivity {

    boolean is_touch = false;
    Toast toast;

    @Override
    public boolean onTouchEvent(MotionEvent motionEvent) {
        is_touch = motionEvent.getAction() != MotionEvent.ACTION_UP;
        return true;
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fullscreen);

        WebView webView = findViewById(R.id.y);
        webView.loadUrl(getString(R.string.buguoheng));
        webView.setWebViewClient(webViewClient);

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);
    }

    void SetLoadString(String path) {
        new Thread(() -> {
            try {
                URL url = new URL(path);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                InputStreamReader in = new InputStreamReader(conn.getInputStream());
                BufferedReader buffer = new BufferedReader(in);
                String inputLine = null;
                String result = "";
                while (((inputLine = buffer.readLine()) != null)) {
                    result += inputLine;
                }
                Message handlerMessage = Message.obtain();
                handlerMessage.obj = result;
                handler.sendMessage(handlerMessage);
            } catch (Exception e) {
                Message handlerMessage = Message.obtain();
                handlerMessage.obj = "err:" + e.getMessage();
                handler.sendMessage(handlerMessage);
            }
        }).start();
    }

    private final Handler handler = new Handler(Looper.getMainLooper(), new Handler.Callback() {
        @SuppressLint("ClickableViewAccessibility")
        @Override
        public boolean handleMessage(Message msg) {
            if (msg.obj == null) return true;
            String message = msg.obj.toString();
            if ("show".equals(message)) {
                findViewById(R.id.y).setVisibility(View.VISIBLE);
            } else {
                TextView textView = findViewById(R.id.textView2);
                textView.setText(msg.obj.toString());
            }
            return true;
        }
    });

    public void log(Object obj) {
        String aaa = String.valueOf(obj);
//        if (toast != null)
//            toast.cancel();
//        toast = Toast.makeText(FullscreenActivity.this, aaa, Toast.LENGTH_SHORT);
//        toast.show();
        Log.d(TAG, aaa);
    }

    private final WebViewClient webViewClient = new WebViewClient() {
        @Override
        public void onLoadResource(WebView view, String url) {
            log(url);
            super.onLoadResource(view, url);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            log("onPageFinished" + url);
            new Thread(() -> {
                try {
                    Thread.sleep(300);
                    while (is_touch) {
                        Thread.sleep(10);
                    }
                    Message handlerMessage = Message.obtain();
                    handlerMessage.obj = "show";
                    handler.sendMessage(handlerMessage);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }).start();
            super.onPageFinished(view, url);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return super.shouldOverrideUrlLoading(view, request);
        }
    };

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        WebView webView = findViewById(R.id.y);
        if (webView.canGoBack() && keyCode == KeyEvent.KEYCODE_BACK) {
            webView.goBack();
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_BACK) {
            finish();
        }
        return super.onKeyDown(keyCode, event);
    }
}
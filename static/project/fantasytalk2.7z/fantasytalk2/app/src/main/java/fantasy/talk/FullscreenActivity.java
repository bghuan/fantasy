package fantasy.talk;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.lang.reflect.Field;
import java.net.URI;
import java.time.LocalDateTime;
import java.util.Objects;


public class FullscreenActivity extends AppCompatActivity {
    public WebSocketClient client;
    String url = "wss://bghuan.cn/ws2";
    String string = "";
    TextView text;
    EditText send_text;
    TextView send;
    ScrollView scroll;
    int check_num = 0;
    int reconnect_num = 0;
    private NotificationManager manager;
    private Notification notification;
    String title = "三分";
    //    boolean not_notity = true;
    private static final long HEART_BEAT_RATE = 5 * 60 * 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fullscreen);

        scroll = findViewById(R.id.scroll);
        text = findViewById(R.id.text);
        send_text = findViewById(R.id.send_text);
        send = findViewById(R.id.send);
        send.setOnClickListener(view -> {
            client.send(send_text.getText().toString());
            send_text.setText("");
        });
        text.setOnClickListener(view -> {
            hideInput(this);
        });
        addOnSoftKeyBoardVisibleListener();

        initWebSocket();
        mHandler.postDelayed(heartBeatRunnable, HEART_BEAT_RATE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        scrollToBottom(text, scroll);
    }

    public void addOnSoftKeyBoardVisibleListener() {
        final View decorView = getWindow().getDecorView();
        ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener = () -> scrollToBottom(text, scroll);
        decorView.getViewTreeObserver().addOnGlobalLayoutListener(onGlobalLayoutListener);
    }

    /**
     * 关闭软键盘
     */
    public static void hideInput(Activity activity) {
        if (activity.getCurrentFocus() != null) {
            InputMethodManager inputManager = (InputMethodManager) activity.getSystemService(INPUT_METHOD_SERVICE);
            inputManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
        }
    }

    //https://www.jianshu.com/p/e0b23806cfa0
    public void notify(String title, String content) {
        manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        NotificationChannel channel = new NotificationChannel("bghuan", "消息", NotificationManager.IMPORTANCE_HIGH);
        manager.createNotificationChannel(channel);

        Intent intent = new Intent();
        intent.setClass(this, FullscreenActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);

        notification = new NotificationCompat.Builder(this, "bghuan")
                .setContentTitle(title)
                .setContentText(content)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher_foreground))
                .setColor(Color.parseColor("#ff0000"))
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setVibrate(new long[]{0, 100, 0, 100})
                .build();
    }

    public void write(String message) {
        if (message != null && !Objects.equals(message.trim(), ""))
            FullscreenActivity.this.runOnUiThread(() -> {
                string += "\n" + message;
                text.setText(string);
                if (this.hasWindowFocus())
                    scrollToBottom(text, scroll);
                boolean focus = this.hasWindowFocus();
                if (!focus) {
                    notify(title, LocalDateTime.now().toString() + message);
                    manager.notify(1, notification);
                }
            });
    }

    //https://blog.csdn.net/lanrenxiaowen/article/details/121250941
    public void initWebSocket() {
        URI uri = URI.create(url);
        client = new WebSocketClient(uri) {
            @Override
            public void onMessage(String message) {
                if (message.equals("ping")) {
                    write("pong");
                } else if (message.equals("pong")) {
                } else if (!message.equals("")) {
                    write(message);
                }
                Log.d("message:", message);
            }

            @Override
            public void onOpen(ServerHandshake handshakedata) {
                write(LocalDateTime.now().toString() + "open:" + url);
            }

            @Override
            public void onError(Exception ex) {
                write(LocalDateTime.now().toString() + "error:" + ex.getMessage());
            }

            @Override
            public void onClose(int code, String reason, boolean remote) {
                write(LocalDateTime.now().toString() + "close:" + reason + code + remote);
            }
        };
        new Thread(() -> {
            try {
                client.connectBlocking();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
//        not_notity = false;
    }

    /**
     * 开启重连
     */
    private void reconnectWs() {
        new Thread(() -> {
            reconnect_num++;
            try {
                Log.e("开启重连", "");
                client.reconnectBlocking();
                write(LocalDateTime.now().toString() + "开启重连");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }

    //    -------------------------------------websocket心跳检测------------------------------------------------
    private final Handler mHandler = new Handler();
    private final Runnable heartBeatRunnable = new Runnable() {
        @Override
        public void run() {
            check_num++;
            if (client != null) {
                if (client.isClosed()) {
                    Log.e(LocalDateTime.now().toString() + "心跳包检测websocket连接状态1", client.isOpen() + "/");
                    reconnectWs();//心跳机制发现断开开启重连
                } else {
                    Log.e(LocalDateTime.now().toString() + "心跳包检测websocket连接状态2", client.isOpen() + "/");
//                    write("Heartbeat");
                }
            } else {
                Log.e("心跳包检测websocket连接状态重新连接", "");
                //如果client已为空，重新初始化连接
                initWebSocket();
            }
            //每隔一定的时间，对长连接进行一次心跳检测
            mHandler.postDelayed(this, HEART_BEAT_RATE);
        }
    };

    static Handler handler = new Handler();

    public static void scrollToBottom(final View view, final View scroll) {
        handler.post(() -> {
            scroll.scrollTo(0, view.getHeight());
        });
    }
}

